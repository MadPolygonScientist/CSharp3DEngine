﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace _2dgraphics
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void ScreenPanel_Paint(object sender, PaintEventArgs e)
        {

            Pen linepen = new Pen(Color.White);
            Graphics draw = ScreenPanel.CreateGraphics();
            //first point
            float x1 = 0.0f;
            float y1 = -0.8f;

            //second point
            float x2 = 1.0f;
            float y2 = 0.8f;
            float z2 = 0.0f;
            //third points
            float x3 = -1.0f;
            float y3 = 0.8f;
            float z3 = 0.0f;

            for (float time = 0; time < 40000; time+= 0.1f)
            {
                //rotation and transformation X
                x2 = (float)(0.5f * Math.Sin(time / 100)) * 100 + 100;
                x3 = (float)(0.5f * Math.Sin(time / 100 + 3.141f)) * 100  + 100;
                //rotation and transformation Z
                z2 = (float)(0.0625f * Math.Cos(time / 100)) + 1;
                z3 = (float)(0.0625f * Math.Cos(time /100 + 3.141f)) + 1;
                //transform Y
                float pointy1 = y1 * 100 + 100;
                float pointy3 = y2 * 100 + 100;
                float pointy2 = y3 * 100 + 100;
                //transform x1
                float pointx1 = x1 * 100 + 100;
                //drawing routine
                draw.Clear(Color.Black);
                draw.DrawLine(linepen, (pointx1), (pointy1), x2, (pointy2 / z2));
                draw.DrawLine(linepen, (pointx1), (pointy1), x3, (pointy3 / z3));
                draw.DrawLine(linepen, x2, (pointy2 / z2), x3, (pointy3 / z3));
            }
        }
    }
}
